# MakeUp - LITE - Code
Ultra high performance Minecraft shader (Java).

## Version: 3.2

### This version works in Optifine and Iris 1.5.1 or higher.

Features:

Shadows
Motion blur
Custom colors
Auto exposure
TAA (Temporal antialiasing)
Flipped image reflex
Waving plants
Distant horizons (Iris only)
And more...

Tested on:
Minecraft 1.12, 1.16 - 1.21.x
Nvidia, Intel and AMD.
Windows 10 and 11.
Optifine and Iris

## You can:
* You can use the shader without restrictions.
* You can fork the shader from: [https://github.com/javiergcim/MakeUpUltraFast](https://github.com/javiergcim/MakeUpUltraFast)
* You can modify this shader for any purpose.
* If you modify or use the shader please add a credit, and the official URLs if possible: [https://modrinth.com/shader/makeup-ultra-fast-shaders](https://modrinth.com/shader/makeup-ultra-fast-shaders), [https://www.planetminecraft.com/mod/makeup-ultra-fast-shader/](https://www.planetminecraft.com/mod/makeup-ultra-fast-shader/), [https://www.curseforge.com/minecraft/customization/makeup-ultra-fast-shader](https://www.curseforge.com/minecraft/customization/makeup-ultra-fast-shader) and/or [https://github.com/javiergcim/MakeUpUltraFast](https://github.com/javiergcim/MakeUpUltraFast)

Notification is not required, but would be appreciated.
